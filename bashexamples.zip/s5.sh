#!/bin/bash

declare -i n1 n2 sum

echo enter first value:
read n1

echo enter second value:
read n2

sum=$n1+$n2

echo "the sum of $n1 and $n2 is $sum"
