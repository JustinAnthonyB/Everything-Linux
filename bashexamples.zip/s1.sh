#!/bin/bash

cal
date
whoami
