#!/bin/bash

echo command name is $0
echo first arg: $1
echo second arg: $2
echo third arg: $3
echo all args: $*
echo number of args: $#
