#!/bin/bash

echo what is your name?

read name

echo thank you, your name is $name
