#!/bin/bash

declare -i n1 n2 sum

n1=$1
n2=$2
sum=$n1+$n2

echo "the sum of $n1 and $n2 is $sum"
