#!/bin/bash

for val in one two three four five
do
 echo $val
done
